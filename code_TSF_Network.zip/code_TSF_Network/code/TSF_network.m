function G = TSF_network(N, aved, lamda, nc, interedge)
% TSF_NETWORK  Generate a modular scale-free-like network with nc communities.
%
%   G = TSF_network(N, aved, lamda, nc, interedge)
%
%   Inputs:
%       N         - total number of nodes
%       aved      - target average degree for each community
%       lamda     - parameter passed to random_scale_free_network
%       nc        - number of communities (if nc == 1, generate a single SF network)
%       interedge - number of inter-community edges added per community link
%
%   Output:
%       G         - N-by-N adjacency matrix (binary, symmetric, zero diagonal)
%
%   Notes:
%       - This function uses the internal generator:
%             random_scale_free_network(n_nodes, aved, lamda)
%         which returns a sparse adjacency matrix of size n_nodes-by-n_nodes.
%       - Only base MATLAB functions are used (no toolboxes required).
%
%   Version 1.0 (2025)
%   Author: Ye Deng (Beijing Normal University)
%   License: GPL-2.0

    % ---- Argument checks ----
    if nargin < 5
        error('TSF_network requires 5 input arguments: N, aved, lamda, nc, interedge.');
    end
    if N <= 0 || nc <= 0 || interedge < 0
        error('N and nc must be positive, and interedge must be non-negative.');
    end
    if nc > N
        error('Number of communities nc cannot exceed number of nodes N.');
    end

    % ---- Single-community case ----
    if nc == 1
        G = full(random_scale_free_network(N, aved, lamda));
        G = double((G + G') > 0); % ensure symmetry
        G(1:N+1:end) = 0;         % zero diagonal
        return;
    end

    % ---- Step 1: assign community sizes ----
    % ensure each community has at least one node
    communitySizes = ones(1, nc);
    remainingNodes = N - nc;
    if remainingNodes < 0
        error('N must be at least nc so that each community has at least one node.');
    end

    % randomly distribute remaining nodes
    for k = 1:remainingNodes
        idx = randi(nc);
        communitySizes(idx) = communitySizes(idx) + 1;
    end

    % ---- Step 2: generate each community ----
    G_temp = cell(nc, 1);
    for i = 1:nc
        ni = communitySizes(i);
        Gi = full(random_scale_free_network(ni, aved, lamda));
        Gi = double((Gi + Gi') > 0); % symmetrize
        Gi(1:ni+1:end) = 0;          % zero diagonal
        G_temp{i} = Gi;
    end

    % ---- Step 3: assemble block-diagonal matrix ----
    G = blkdiag(G_temp{:});
    N_check = size(G, 1);
    if N_check ~= N
        error('Internal size mismatch: expected N = %d, got %d.', N, N_check);
    end

    % ---- Step 4: build node index sets for each community ----
    node_indices = cell(nc, 1);
    current_index = 1;
    for i = 1:nc
        num_nodes_in_community = communitySizes(i);
        node_indices{i} = current_index:(current_index + num_nodes_in_community - 1);
        current_index = current_index + num_nodes_in_community;
    end

    % ---- Step 5: connect communities with inter-community edges ----
    remaining_communities = 1:nc;
    selected_communities  = [];

    % 5.1 pick initial pair of communities
    if numel(remaining_communities) < 2
        return; % degenerate, should not occur if nc >= 2
    end
    perm = randperm(numel(remaining_communities), 2);
    first_pair = remaining_communities(perm);
    selected_communities = first_pair;
    remaining_communities(perm) = [];

    i = first_pair(1);
    j = first_pair(2);
    G = add_interedges(G, node_indices{i}, node_indices{j}, interedge);

    % 5.2 iteratively attach remaining communities to any selected one
    while ~isempty(remaining_communities)
        % choose a new community
        idx_new = randperm(numel(remaining_communities), 1);
        new_community = remaining_communities(idx_new);

        % choose a target from already connected communities
        idx_target = randperm(numel(selected_communities), 1);
        target_community = selected_communities(idx_target);

        G = add_interedges(G, node_indices{new_community}, ...
                              node_indices{target_community}, interedge);

        % update sets
        remaining_communities(idx_new) = [];
        selected_communities(end+1)    = new_community;
    end

    % final safety: enforce symmetry & zero diagonal
    G = double((G + G') > 0);
    G(1:N+1:end) = 0;
end

% -------------------------------------------------------------------------
function G = add_interedges(G, nodes_a, nodes_b, interedge)
% ADD_INTEREDGES  Add undirected edges between two communities.
    if interedge <= 0
        return;
    end
    na = numel(nodes_a);
    nb = numel(nodes_b);
    for e = 1:interedge
        u = nodes_a(randi(na));
        v = nodes_b(randi(nb));
        if u ~= v
            G(u, v) = 1;
            G(v, u) = 1;
        end
    end
end
