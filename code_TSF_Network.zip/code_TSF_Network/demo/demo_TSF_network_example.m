function demo_TSF_network_example()
% DEMO_TSF_NETWORK_EXAMPLE
%   Minimal demo for the TSF_network generator.
%
%   Example parameters:
%       N        = 1000;
%       aved     = 10;
%       lamda    = 2.5;
%       nc       = 5;
%       interedge = 5;
%
%   Usage:
%       demo_TSF_network_example;

    fprintf('\n=== Demo: TSF_network example ===\n');

    % Example parameters
    N         = 1000;
    aved      = 10;
    lamda     = 2.5;
    nc        = 5;
    interedge = 5;

    fprintf('Parameters:\n');
    fprintf('  N = %d, aved = %.2f, lamda = %.2f, nc = %d, interedge = %d\n', ...
            N, aved, lamda, nc, interedge);

    % Generate network
    tic;
    G = TSF_network(N, aved, lamda, nc, interedge);
    t = toc;

    % Basic statistics
    deg   = sum(G, 2);
    m     = nnz(triu(G));  % number of edges
    kmean = mean(deg);

    fprintf('Network generated in %.3f seconds.\n', t);
    fprintf('  Nodes  : %d\n', N);
    fprintf('  Edges  : %d\n', m);
    fprintf('  Mean k : %.3f\n', kmean);

    % Optional: visualize degree distribution
    figure;
    histogram(deg);
    xlabel('Degree');
    ylabel('Count');
    title('TSF network degree distribution');

    fprintf('Demo completed.\n');
end
