%% Batch processing: iterate over each network under the "test" directory and run multiple igraph community-detection algorithms
% Output (per network):
%   - Name (folder name)
%   - Number of nodes N
%   - Number of detected communities under each algorithm

clear; clc;

%% 0. Root directory (each subfolder corresponds to one network)
baseDir = 'C:\Users\Administrator\Desktop\PHI Community';

% List all subfolders
d = dir(baseDir);
isSub = [d.isdir] & ~ismember({d.name}, {'.','..'});
subDirs = d(isSub);
nNet = numel(subDirs);
if nNet == 0
    error('No subfolders were found under %s.', baseDir);
end

%% 1. Optional: fix random seed for reproducibility (set only once)
rng(1);                 % MATLAB built-in RNG
% igraph.rng('default'); % igraph internal RNG (optional)

%% 2. Pre-allocate the result table
algNames = {'Walktrap','LabelProp','Infomap','Louvain','Leiden'};

varNames = [{'network_name','N'}, strcat('nComm_', algNames)];
varTypes = [{'string','double'}, repmat({'double'}, 1, numel(algNames))];

T = table('Size', [nNet, numel(varNames)], ...
          'VariableNames', varNames, ...
          'VariableTypes', varTypes);

%% 3. Main loop: process each network
for idx = 1:nNet

    netName   = subDirs(idx).name;
    netFolder = fullfile(baseDir, netName);
    fprintf('\n=== (%d/%d) Processing network: %s ===\n', idx, nNet, netName);

    % 3.1 Find the .mat file in this folder (by default, take the first one)
    matFiles = dir(fullfile(netFolder, '*.mat'));
    if isempty(matFiles)
        warning('  No .mat file found in folder %s. Skipping.', netFolder);
        continue;
    end
    matPath = fullfile(netFolder, matFiles(1).name);
    fprintf('  Using adjacency-matrix file: %s\n', matFiles(1).name);

    % 3.2 Load adjacency matrix G
    data = load(matPath);

    if ~isfield(data, 'G')
        warning('  Variable G was not found in file %s. Skipping this network.', matPath);
        continue;   % move to next network
    end
    G = data.G;

    % 3.3 Remove self-loops + sparsify + symmetrize + binarize (following your convention)
    G = double(G);
    G = G - diag(diag(G));          % remove diagonal (self-loops)
    G = sparse(G);

    % If the network is undirected and unweighted:
    G = (G + G.') > 0;
    G = sparse(double(G));

    N = size(G,1);

    % Record network name & N
    T.network_name(idx) = string(netName);
    T.N(idx)            = N;

    %% 4. Call igraph.cluster for each algorithm
%%%%% In this study, the Leading Eigenvector method is computed using the Brain Connectivity Toolbox (BCT).

    % --- 4.1 Walktrap communities ---
    Ci_walktrap = [];
    try
        Ci_walktrap = igraph.cluster(G, 'walktrap', ...
                                     'nSteps', 4);  % default is 4
    catch ME
        warning('  Walktrap failed: %s', ME.message);
    end

    % --- 4.2 Label propagation communities ---
    Ci_lp = [];
    try
        Ci_lp = igraph.cluster(G, 'labelpropagation', ...
                               'mode', 'all');
    catch ME
        warning('  LabelPropagation failed: %s', ME.message);
    end

    % --- 4.3 Infomap communities ---
    Ci_infomap = [];
    try
        Ci_infomap = igraph.cluster(G, 'infomap', ...
                                    'nTrials', 10);
    catch ME
        warning('  Infomap failed: %s', ME.message);
    end

    % --- 4.4 Louvain (resolution = 1.0) ---
    Ci_louvain = [];
    try
        Ci_louvain = igraph.cluster(G, 'louvain', ...
                                    'resolution', 1.0);
    catch ME
        warning('  Louvain (res=1.0) failed: %s', ME.message);
    end

    % --- 4.5 Leiden (metric = modularity; corresponds to your Leiden(Q)) ---
    Ci_leiden_Q = [];
    try
        Ci_leiden_Q = igraph.cluster(G, 'leiden', ...
                                     'resolution', 1.0, ...
                                     'randomness', 0.01, ...
                                     'metric', 'modularity');
    catch ME
        warning('  Leiden (modularity) failed: %s', ME.message);
    end

    %% 5. Count communities for each algorithm and write to the result table
    T.nComm_Walktrap(idx)   = local_count_communities(Ci_walktrap);
    T.nComm_LabelProp(idx)  = local_count_communities(Ci_lp);
    T.nComm_Infomap(idx)    = local_count_communities(Ci_infomap);
    T.nComm_Louvain(idx)    = local_count_communities(Ci_louvain);
    T.nComm_LeidenQ(idx)    = local_count_communities(Ci_leiden_Q);
end

%% 6. Save the summary table
outMat = fullfile(baseDir, 'community_summary_igraph.mat');
outCsv = fullfile(baseDir, 'community_summary_igraph.csv');
save(outMat, 'T');
writetable(T, outCsv);
fprintf('\nAll processing completed. Results saved to:\n  %s\n  %s\n', outMat, outCsv);

%% ===== Local helper function: count the number of communities =====
function n = local_count_communities(Ci)
    if isempty(Ci)
        n = NaN;
    else
        n = numel(unique(Ci));
    end
end
