function G = random_scale_free_network(N, aved, lamda)
% RANDOM_SCALE_FREE_NETWORK  Generate an undirected scale-free-like network.
%
%   G = random_scale_free_network(N, aved, lamda)
%
%   Inputs:
%       N      - number of nodes
%       aved   - target average degree
%       lamda  - exponent parameter (> 1)
%
%   Output:
%       G      - N-by-N sparse adjacency matrix (binary, symmetric, zero diagonal)
%
%   The algorithm follows a simple preferential attachment / power-law
%   sampling scheme: node indices are sampled with probability
%       p(i) ∝ i^(-1/(lamda-1))
%   and edges are added between distinct nodes until the desired number
%   of edges (N * aved / 2) is reached.
%
%   Only base MATLAB functions are used.
%
%   Version 1.0 (2025)
%   Author: Ye Deng (Beijing Normal University)
%   License: GPL-2.0

    if nargin < 3
        error('random_scale_free_network requires N, aved, lamda.');
    end
    if N <= 0 || aved < 0 || lamda <= 1
        error('Invalid parameters: N > 0, aved >= 0, lamda > 1 are required.');
    end

    a = 1 / (lamda - 1);
    i = (1:N)';
    p = i.^(-a);
    p = p / sum(p);  % normalize

    G  = sparse(N, N);
    NE = 0;
    targetEdges = N * aved / 2;

    while NE < targetEdges
        v1 = unequalsample(p);
        v2 = unequalsample(p);

        if v1 == v2
            continue;
        end
        if G(v1, v2) == 1
            continue;
        end

        G(v1, v2) = 1;
        G(v2, v1) = 1;
        NE = NE + 1;
    end

    % ensure zero diagonal explicitly
    G(1:N+1:end) = 0;
end

% -------------------------------------------------------------------------
function idx = unequalsample(p)
% UNEQUALSAMPLE  Draw a single index according to probability vector p.
    % p should be a column or row vector with non-negative entries
    cdf = cumsum(p(:));
    r   = rand();
    idx = find(cdf >= r, 1, 'first');
end
