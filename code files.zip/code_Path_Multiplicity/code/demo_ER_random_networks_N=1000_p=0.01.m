function demo_ER_random_networks()
% DEMO for Path_Mulptilicity using the ER random network.

fprintf('\n=== Demo: ER_random_networks_N=1000_p=0.01 ===\n');

% Load example data
dataFile = fullfile('data','ER_random_networks_N=1000_p=0.01.mat');
S = load(dataFile);

if isfield(S,'A')
    A = S.A;
else
    error('MAT file must contain variable A (adjacency matrix).');
end

n = size(A,1);
fprintf('Network loaded. #Nodes = %d\n', n);

% Run algorithm
tic;
[H_matrix, PHD, PHI] = Path_Mulptilicity(A);
t = toc;

fprintf('PHI = %.6f\n', PHI);
fprintf('Mean PHD = %.6f\n', mean(PHD));
fprintf('Time = %.3f seconds\n', t);

% Optional visualization
mask = triu(true(n),1);
vals = H_matrix(mask);
vals = vals(vals>0);

if ~isempty(vals)
    figure;
    histogram(vals);
    xlabel('Shortest-path count h');
    ylabel('Frequency');
    title('Path multiplicity distribution');
end

fprintf('Demo completed.\n');
end
