# Path_Mulptilicity (MATLAB Implementation)

This package provides a MATLAB implementation of the **Path Mulptilicity** algorithm for computing  
(1) the path hesitation matrix `H_matrix`,  
(2) the node-level path hesitation degree `PHD`,  
(3) the global path hesitation index `PHI`.

---

## 1. System Requirements
- MATLAB R2022a (tested)
- Operating systems: Windows / macOS / Linux supported by MATLAB
- No additional toolboxes required

---

## 2. Installation
1. Unzip the package.
2. Open MATLAB and add the `code/` folder to the MATLAB path:
   ```matlab
   addpath(genpath('code'));
   Example data (ER_random_networks_N=1000_p=0.01.mat) is stored in the data/ folder.

---
## 3. Demo

Run the following script to test the algorithm:

demo_ER_random_networks_N=1000_p=0.01


The script will:

Load the example network

Compute H_matrix, PHD, and PHI

Display basic statistics

---
## 4. Usage

Main function:

[H_matrix, PHD, PHI] = Path_Mulptilicity(A);


Input:

A — n×n adjacency matrix (binary, undirected, no self-loops)

Outputs:

H_matrix — number of shortest paths between node pairs

PHD — path hesitation degree of each node

PHI — global path hesitation index

Example:

load('data/ER_random_networks_N=1000_p=0.01.mat'); % variable A
[H, PHD, PHI] = Path_Mulptilicity(A);
disp(PHI);

---
## 5. Reproducibility

The functions in code/ are sufficient to reproduce the core quantitative metrics in the manuscript (H_matrix, PHD, PHI).
Users may compute additional statistics or generate figures based on H_matrix.

6. License

This software is distributed under the GPL-2.0 License.
See LICENSE.txt for details.
