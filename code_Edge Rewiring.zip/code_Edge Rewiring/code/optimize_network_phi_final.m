function result = optimize_network_phi_final(G0, numTargets, Q, gamma)
%OPTIMIZE_NETWORK_PMI Perform greedy network rewiring to maximise a chosen metric.
%
%   result = OPTIMIZE_NETWORK_PMI(G0, numTargets, Q, gamma)
%   takes an initial connected adjacency matrix G0 (binary and symmetric),
%   and performs a sequence of greedy rewiring steps to maximise a target
%   network metric.  The target metric in this implementation is the
%   probabilistic modular interaction (PMI) value obtained from
%   route_hesitation_index_fast.  The associated metric tracked alongside
%   is the community number obtained from the modularity_und function.
%
%   Some initial networks may already have high baseline metric values 
%   (e.g., PMI or community number), potentially biasing the early search 
%   toward local optima; accordingly, the first recorded iteration reflects 
%   the best outcome of the initial rewiring trials rather than the original network  
%   Therefore, the metric of the initial network G0 is NOT used to
%   initialise the optimisation trajectory: the first recorded state
%   G^(1) is defined as the best candidate among rewired networks
%   generated from G0, and its metric value can be either higher or lower
%   than that of G0. From G^(2) onward, the optimisation enforces a
%   non-decreasing objective sequence (phi_t >= phi_{t-1}).
%
%   Inputs
%   ------
%   G0         : NxN binary adjacency matrix of the starting network. The
%                network must be undirected, unweighted, and connected.
%   numTargets : Number of valid rewired networks to record.  The
%                algorithm terminates after this many iterations regardless
%                of improvement.  Typical values are 40 or 100.
%   Q          : Number of candidate rewiring trials generated at each
%                iteration.  Higher values increase search breadth but
%                require more computation.  Default is 10000 if omitted.
%   gamma      : Resolution parameter for community detection in
%                modularity_und.  Default is 1.0 if omitted.
%
%   Outputs
%   -------
%   result : structure with the following fields
%       .G_list      : cell array of recorded adjacency matrices
%       .phi_list    : vector of PMI values corresponding to G_list
%       .nc_list     : vector of community numbers corresponding to G_list
%       .finalG      : adjacency matrix of the last recorded network
%       .final_phi   : PMI value of the last recorded network
%       .final_nc    : community number of the last recorded network
%
%   The algorithm proceeds as follows:
%     1. Take G0 purely as a rewiring seed without using its metric
%        value as an optimisation reference.
%     2. For the first recorded iteration t = 1, generate Q candidate
%        rewired networks from G^(0)=G0, and select the candidate with
%        the maximum target metric as G^(1), regardless of how its
%        metric compares to that of G0.
%     3. For each subsequent iteration t = 2..numTargets, generate Q
%        candidates from G^(t-1) and select among those with phi >=
%        phi(G^(t-1)), thereby enforcing a non-decreasing objective
%        sequence from the second recorded state onward.
%     4. Record the chosen network and its metrics at each iteration
%        until numTargets networks have been recorded or no acceptable
%        move can be found within a prescribed trial cap.
%
%   Example usage:
%       G0 = rand(50)<0.1; G0 = triu(G0,1); G0 = G0+G0';
%       G0 = adjust_to_connected(G0); % ensure connected
%       result = optimize_network_phi_without_initial(G0, 40, 10, 1);
%       plot(result.phi_list, result.nc_list, 'o');
%       xlabel('PMI'); ylabel('Community number');
%
%   Note: This function assumes the presence of the functions
%   route_hesitation_index_fast and modularity_und in the MATLAB path.
%   The connectivity test is implemented via a custom BFS for efficiency.

% -------------------------------------------------------------------------
% 0. Set defaults and validate input
% -------------------------------------------------------------------------
if nargin < 3 || isempty(Q)
    Q = 10;
end
if nargin < 4 || isempty(gamma)
    gamma = 1;
end

% Verify input is square and binary, undirected
[N, M] = size(G0);
if N ~= M
    error('G0 must be a square adjacency matrix.');
end
if ~isequal(G0, G0') || any(G0(:) < 0) || any(G0(:) > 1)
    error('G0 must be an undirected, binary adjacency matrix.');
end

% Ensure connectivity of G0
if ~is_connected(G0)
    error('Initial network G0 must be connected.');
end

% -------------------------------------------------------------------------
% 1. Prepare result storage
% -------------------------------------------------------------------------
result.G_list   = cell(numTargets, 1);
result.phi_list = zeros(numTargets, 1);
result.nc_list  = zeros(numTargets, 1);

% Initialise current network as G0, but do NOT use its metrics
G_current   = G0;
current_phi = NaN;   % indicates that no recorded state yet
current_nc  = NaN;

% Record counter
count = 0;

% -------------------------------------------------------------------------
% 2. Main optimisation loop
%    From the second recorded state onward, objective sequence is
%    enforced to be non-decreasing.
% -------------------------------------------------------------------------
while count < numTargets
    foundAcceptable    = false;
    max_repeat_trials  = 100;
    repeat_counter     = 0;

    while ~foundAcceptable && repeat_counter < max_repeat_trials
        repeat_counter = repeat_counter + 1;

        % -------------------------------------------------------------
        % 2.1 Generate Q candidate networks from current state
        % -------------------------------------------------------------
        candidate_phi = -inf(Q, 1);
        candidate_nc  = nan(Q, 1);
        candidateG    = cell(Q, 1);

        % Edge list of current network
        [rows, cols] = find(triu(G_current, 1));
        m = numel(rows);

        for q = 1:Q
            G_trial = G_current;

            % Determine a random rewiring budget between 1 and m
            if m > 0
                b = randi(m);
            else
                b = 0;
            end

            % Perform b successful edge swaps, preserving connectivity
            max_attempts  = b * 10;
            success_swaps = 0;
            attempts      = 0;

            while success_swaps < b && attempts < max_attempts
                attempts = attempts + 1;

                % Recompute edges because G_trial changes after swaps
                [erows, ecols] = find(triu(G_trial, 1));
                numEdges = numel(erows);
                if numEdges < 2
                    break;
                end

                % Pick two distinct edges uniformly at random
                idx = randperm(numEdges, 2);
                i  = erows(idx(1)); j  = ecols(idx(1));
                k  = erows(idx(2)); l  = ecols(idx(2));

                % Skip if endpoints are not all distinct
                if numel(unique([i j k l])) < 4
                    continue;
                end

                % Two possible reconnections: (i,k)-(j,l) or (i,l)-(j,k)
                if rand < 0.5
                    a = i; b1 = k; c = j; d = l;
                else
                    a = i; b1 = l; c = j; d = k;
                end

                % Check that new edges do not already exist and are not self-loops
                if G_trial(a, b1) || G_trial(c, d) || a == b1 || c == d
                    continue;
                end

                % Perform the swap
                G_trial(i, j) = 0; G_trial(j, i) = 0;
                G_trial(k, l) = 0; G_trial(l, k) = 0;
                G_trial(a, b1) = 1; G_trial(b1, a) = 1;
                G_trial(c, d) = 1; G_trial(d, c) = 1;

                % Check connectivity; if broken, revert and continue
                if ~is_connected(G_trial)
                    % revert changes
                    G_trial(a, b1) = 0; G_trial(b1, a) = 0;
                    G_trial(c, d) = 0; G_trial(d, c) = 0;
                    G_trial(i, j) = 1; G_trial(j, i) = 1;
                    G_trial(k, l) = 1; G_trial(l, k) = 1;
                    continue;
                end

                success_swaps = success_swaps + 1;
            end

            % If no swaps succeeded, skip this candidate
            if success_swaps == 0
                continue;
            end

            % Evaluate target and associated metrics on the trial network
            try
                [phi_val, ~, ~, ~] = route_hesitation_index_fast(G_trial);
            catch ME
                warning('Error evaluating route_hesitation_index_fast: %s', ME.message);
                continue;
            end
            try
                [Ci, ~] = modularity_und(G_trial, gamma);
            catch ME2
                warning('Error evaluating modularity_und: %s', ME2.message);
                continue;
            end
            nc_val = max(Ci);

            candidate_phi(q) = phi_val;
            candidate_nc(q)  = nc_val;
            candidateG{q}    = G_trial;
        end

        % If all candidates are invalid, proceed to the next round.
        if all(isinf(candidate_phi))
            continue;
        end

        % -------------------------------------------------------------
        % 2.2 Acceptance Rules:
        % - If there are no records yet (count == 0), perform internal PK within the candidate set,
        %   select the one with the largest phi as G^(1), and ignore the G0 indicator.
        % - If there are already records (count >= 1), only accept candidates with phi >= current_phi,
        %   ensuring a monotonically non-decreasing sequence starting from the second record.
        % -------------------------------------------------------------
        max_phi = max(candidate_phi);

        if isnan(current_phi)
            % First record: Only internal competition among candidates.
            foundAcceptable = true;
        else
            % Subsequent record: Requirement: phi_new >= phi_current
            if max_phi < current_phi
                % All candidates in this round are worse than the current best; retrying.
                continue;
            else
                foundAcceptable = true;
            end
        end

        % -------------------------------------------------------------
        % 2.3 Select the candidate with the largest phi value and record it.
        % -------------------------------------------------------------
        if foundAcceptable
            idxs       = find(candidate_phi == max_phi);
            chosen_idx = idxs(randi(numel(idxs)));

            G_current   = candidateG{chosen_idx};
            current_phi = candidate_phi(chosen_idx);
            current_nc  = candidate_nc(chosen_idx);

            count = count + 1;
            result.G_list{count}   = G_current;
            result.phi_list(count) = current_phi;
            result.nc_list(count)  = current_nc;
        end
    end

    if ~foundAcceptable
        warning('Could not find an acceptable candidate after %d attempts. Terminating.', max_repeat_trials);
        break;
    end
end

% -------------------------------------------------------------------------
% 3. Truncate in case of early termination and set final outputs
% -------------------------------------------------------------------------
result.G_list   = result.G_list(1:count);
result.phi_list = result.phi_list(1:count);
result.nc_list  = result.nc_list(1:count);

if count >= 1
    result.finalG    = result.G_list{count};
    result.final_phi = result.phi_list(count);
    result.final_nc  = result.nc_list(count);
else
    % No valid optimisation step was recorded; fall back to G0
    result.finalG    = G0;
    result.final_phi = NaN;
    result.final_nc  = NaN;
end

end % main function


% =====================================================================
% Helper: connectivity check
% =====================================================================
function tf = is_connected(adj)
%IS_CONNECTED Determine if an undirected network is connected using MATLAB built-in functions.
%   This helper wraps the built-in graph/conncomp functionality.  It
%   constructs a graph object from the adjacency matrix and uses conncomp
%   to count the number of connected components.  Returns true if
%   exactly one component is present.

try
    G_tmp = graph(adj, 'upper');
    comps = conncomp(G_tmp);
    tf = (numel(unique(comps)) == 1);
catch
    % Fallback: assume connected if Graph functions are unavailable
    warning('Graph connectivity functions unavailable, assuming the graph is connected.');
    tf = true;
end
end
