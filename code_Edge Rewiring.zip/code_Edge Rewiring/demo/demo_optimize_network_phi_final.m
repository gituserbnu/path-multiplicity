function demo_optimize_network_phi_final()
% DEMO_OPTIMIZE_NETWORK_PHI_FINAL
%   Minimal demo for optimize_network_phi_final.
%
%   Example parameters:
%       G0;                    % the initial network
%       numTargets = 40;       % number of recorded iterations (networks)
%       Q          = 10000;       % candidates per iteration (increase for better search)
%       gamma      = 1.0;      % resolution parameter for modularity_und
%
%   Usage:
%       demo_optimize_network_phi_final;

    fprintf('\n=== Demo: optimize_network_phi_final ===\n');

    % ---- Dependency check ----
    req = {'optimize_network_phi_final', 'route_hesitation_index_fast', 'modularity_und'};
    for r = 1:numel(req)
        if exist(req{r}, 'file') ~= 2
            error('Required function not found on MATLAB path: %s', req{r});
        end
    end

    % Example parameters
    numTargets = 40;
    Q          = 10000;
    gamma      = 1.0;

    fprintf('Parameters:\n');
    fprintf('numTargets = %d, Q = %d, gamma = %.2f\n', ...
            numTargets, Q, gamma);

   

    % ---- Run optimisation ----
   
    tic;
    result = optimize_network_phi_final(G0, numTargets, Q, gamma);
    t = toc;

    T = numel(result.phi_list);
    fprintf('Optimisation completed in %.3f seconds.\n', t);
    fprintf('  Recorded steps : %d\n', T);
    if T > 0
        fprintf('  Final PMI (phi): %.6g\n', result.final_phi);
        fprintf('  Final nc       : %d\n', result.final_nc);
    else
        fprintf('  No valid step recorded; check Q, connectivity constraints, and dependencies.\n');
    end

    % ---- Optional: plots ----
    if T > 0
        figure;
        plot(1:T, result.phi_list, '-o');
        xlabel('Iteration (recorded step)');
        ylabel('PMI (\\phi)');
        title('PMI trajectory');

        figure;
        plot(1:T, result.nc_list, '-o');
        xlabel('Iteration (recorded step)');
        ylabel('Community number (n_c)');
        title('Community number trajectory');

        figure;
        plot(result.phi_list, result.nc_list, 'o');
        xlabel('PMI (\\phi)');
        ylabel('Community number (n_c)');
        title('PMI vs. community number');
    end

    fprintf('Demo completed.\n');
end

