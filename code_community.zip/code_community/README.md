# Community Detection Benchmark for PHI Analysis

This repository provides MATLAB and Python code for batch processing and benchmarking
multiple community-detection algorithms on a collection of networks,
as used in the analysis of path multiplicity (PHI) and community structure.

The code is designed to ensure transparency and methodological clarity,
and is intended to accompany an academic manuscript submitted to  
*Nature Communications*.

---

## 1. Overview

The main script iterates over a directory of network datasets, where each
subfolder corresponds to one network and contains a MATLAB `.mat` file
with an adjacency matrix `G`.

For each network, the script:

- Loads and preprocesses the adjacency matrix;
- Applies multiple community-detection algorithms;
- Records the number of detected communities under each algorithm;
- Saves the results as both `.mat` and `.csv` summary files.

**Important note on algorithm availability.**  
Although the MATLAB interface of igraph exposes an option named *Leading Eigenvector*,
this method is **not currently executable in the latest MATLAB–igraph release**, which is 
highlighted in the original official code. Therefore, in this study, the Leading Eigenvector 
modularity method (Newman, 2006) is **computed exclusively via the Brain Connectivity Toolbox (BCT)**,
which provides a stable and fully deterministic implementation consistent with the methodological 
description in the manuscript. - In addition, **the MATLAB implementation of the Leiden algorithm may lead to excessive memory usage for medium-to-large networks**, so Leiden-based results are also recommended 
to be computed using the Python version of igraph**, both of which are provided in our code, with the igraph-based implementation available in both MATLAB and Python.


---

## 2. Software Requirements

The code was developed and tested under the following environment:

- MATLAB R2022a
- MATLAB igraph interface  
  https://github.com/igraph/matlab-igraph (latest available release)
- Brain Connectivity Toolbox (BCT)

Corresponding Python scripts for running Leiden are provided in this repository.

The following packages must be installed and accessible:

1. MATLAB igraph interface  
2. Brain Connectivity Toolbox (Rubinov & Sporns, 2010)  
3. *(Optional but recommended)* Python igraph for Leiden analysis  

---

## 3. Input Data Format

### Directory Structure

The root directory should contain multiple subfolders, each representing
a single network:

    PHI Community/
    ├── Network_1/
    │   └── network.mat
    ├── Network_2/
    │   └── network.mat
    └── ...

### Adjacency Matrix

Each `.mat` file must contain a variable named:

    G

where `G` is an `N × N` adjacency matrix.

The script assumes:

- Undirected networks;
- Binary edges (or edges that can be binarized);
- No self-loops (self-loops are removed automatically).

---

## 4. Community-Detection Algorithms

For each network, the following algorithms are applied:

- Walktrap (igraph, default step length = 4)
- Label Propagation (igraph, mode = 'all')
- Infomap (igraph, number of trials = 1)
- Louvain (igraph, resolution = 1.0)
- Leiden (igraph, modularity metric, resolution = 1.0, randomness = 0.01)

All parameters are fixed across networks to ensure comparability.

The Leading Eigenvector modularity method is implemented separately
using the Brain Connectivity Toolbox (BCT), with the resolution parameter
fixed at its default value γ = 1 (classical Newman–Girvan modularity).

---

## 5. Reproducibility

To ensure reproducibility:

- The MATLAB random number generator is fixed using `rng(1)`;
- All algorithmic parameters are explicitly specified;
- Batch processing is deterministic given the input networks and software versions.

In practice, this allows independent readers to reproduce all results
reported in the manuscript.

---

## 6. Output

Two summary files are generated in the root directory:

- `community_summary_igraph.mat`
- `community_summary_igraph.csv`

Each row corresponds to one network, and columns include:

- Network name
- Number of nodes `N`
- Number of detected communities under each algorithm

---

## 7. Usage

1. Set the root directory path in the script:
   
       baseDir = '.../PHI Community';

2. Ensure all required toolboxes are on the MATLAB path.

3. Run the script in MATLAB:

       run batch_community_detection.m

---

## 8. Notes

- The code is intended for research use.
- No proprietary datasets are included.
- The implementation follows standard conventions in network science
  and computational social science.

---

## 9. Citation

If you use this code, please cite the accompanying paper and the
following software packages:

- Rubinov, M., & Sporns, O. (2010). Complex network measures of brain
  connectivity: Uses and interpretations. NeuroImage.
- The igraph software package (Csardi & Nepusz, 2006).

