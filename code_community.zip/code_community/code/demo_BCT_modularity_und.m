function demo_BCT_modularity_und()
% DEMO_BCT_MODULARITY_UND
% Author: Ye Deng
%
% Demo for the Brain Connectivity Toolbox (BCT) function:
%   [Ci, Q] = modularity_und(A, gamma)
%
% This demo:
%   1) Loads an example adjacency matrix from a .mat file (expects variable A)
%   2) Applies standard preprocessing (optional): remove self-loops, symmetrize,
%      and binarize or keep weights (you can toggle via flags below)
%   3) Runs modularity_und with gamma (default 1.0)
%   4) Prints key outputs and timing
%   5) Optional: visualizes community assignment size distribution
%
% Requirements:
%   - BCT function modularity_und.m must be on MATLAB path
%
% -------------------------------------------------------------------------

fprintf('\n=== Demo: BCT modularity_und (undirected) ===\n');

%% 0. Load example data
% IMPORTANT: Please edit this file path to your local data.
dataFile = fullfile('data', 'ER_random_networks_N=1000_p=0.01.mat');

if ~isfile(dataFile)
    error('Data file not found: %s\nPlease place the example .mat under ./data/ or update dataFile.', dataFile);
end

S = load(dataFile);

if isfield(S, 'A')
    A = S.A;
elseif isfield(S, 'G')
    % Allow alternative variable name for convenience
    A = S.G;
else
    error('MAT file must contain variable A (or G) as the adjacency matrix.');
end

if ~ismatrix(A) || size(A,1) ~= size(A,2)
    error('Adjacency matrix must be a square 2D matrix. Got size: %s', mat2str(size(A)));
end

n = size(A,1);
fprintf('Network loaded. #Nodes = %d\n', n);

%% 1. Preprocessing options (align with your study convention as needed)
% Toggle these flags according to your pipeline.
DO_REMOVE_SELF_LOOPS = true;
DO_SYMMETRIZE        = true;   % recommended for undirected modularity_und
DO_BINARIZE          = true;   % set false if you want to keep weights

A = double(A);

if DO_REMOVE_SELF_LOOPS
    A(1:n+1:end) = 0;
end

if DO_SYMMETRIZE
    % Treat as undirected: OR on positive weights
    A = (A > 0) | (A' > 0);
    A = double(A);
end

if DO_BINARIZE
    A = double(A > 0);
end

% Basic validity checks
if any(isnan(A(:))) || any(isinf(A(:)))
    warning('Adjacency matrix contains NaN/Inf; consider cleaning these before modularity_und.');
end

if ~isequal(A, A')
    warning('A is not symmetric after preprocessing. modularity_und assumes undirected networks.');
end

%% 2. Run BCT modularity_und
% Resolution parameter gamma:
%   gamma > 1   => smaller modules
%   0 <= gamma < 1 => larger modules
%   gamma = 1   => classic modularity
gamma = 1.0;

fprintf('Running modularity_und with gamma = %.3f ...\n', gamma);

tic;
[Ci, Q] = modularity_und(A, gamma);
t = toc;

% Ensure column vector
Ci = Ci(:);

%% 3. Report results
nComm = numel(unique(Ci));
fprintf('Q (maximized modularity) = %.6f\n', Q);
fprintf('#Communities = %d\n', nComm);
fprintf('Time = %.3f seconds\n', t);

% Community size summary
sizes = accumarray(Ci, 1);
fprintf('Community size: min=%d, median=%d, max=%d\n', min(sizes), median(sizes), max(sizes));
fprintf('Demo completed.\n');

end
