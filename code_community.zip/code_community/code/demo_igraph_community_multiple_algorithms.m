function demo_igraph_community_multiple_algorithms()
% DEMO_IGRAPH_COMMUNITY_MULTIPLE_ALGORITHMS
% Author: Ye Deng
%
% Demo for batch community detection using MATLAB igraph (MEX) across multiple
% algorithms (Walktrap, Label Propagation, Infomap, Louvain, Leiden).
%
% Input convention:
%   - Each subfolder under baseDir corresponds to one network.
%   - Each subfolder contains at least one .mat file with variable G
%     (adjacency matrix).
%
% Output:
%   - community_summary_igraph.csv
%   - community_summary_igraph.mat
%
% Notes (NC-quality reproducibility):
%   - We fix MATLAB RNG once via rng(1). If your igraph MATLAB wrapper exposes
%     an internal RNG setter, you may optionally set it as well (see below).
%   - For Leiden, we explicitly use modularity metric to match "Leiden(Q)".
%
% Requirements:
%   - MATLAB igraph toolbox providing igraph.cluster(...)
%
% -------------------------------------------------------------------------

fprintf('\n=== Demo: igraph_community_multiple_algorithms (batch) ===\n');

%% 0. Root directory (each subfolder corresponds to one network)
% IMPORTANT: Please edit this path to your local directory structure.
baseDir = 'data';

if ~isfolder(baseDir)
    error('Base directory does not exist: %s', baseDir);
end



% Optional: igraph internal RNG (only if your toolbox supports it).
% Some wrappers expose functions like igraph.rng(...) or igraph_rng_seed(...).
% Uncomment and adjust if available in your environment:
% try
%     igraph.rng('default');
% catch
%     % No igraph RNG setter available; proceed with MATLAB RNG only.
% end

%% 1. Discover subfolders (networks)
d = dir(baseDir);
isSub = [d.isdir] & ~ismember({d.name}, {'.','..'});
subDirs = d(isSub);
nNet = numel(subDirs);

if nNet == 0
    error('No subfolders were found under: %s', baseDir);
end

fprintf('Base directory: %s\n', baseDir);
fprintf('Detected networks (subfolders): %d\n', nNet);

%% 2. Pre-allocate result table
algNames = {'Walktrap','LabelProp','Infomap','Louvain','LeidenQ'};
varNames = [{'network_name','N'}, strcat('nComm_', algNames)];
varTypes = [{'string','double'}, repmat({'double'}, 1, numel(algNames))];

T = table('Size', [nNet, numel(varNames)], ...
          'VariableNames', varNames, ...
          'VariableTypes', varTypes);

%% 3. Main loop: process each network
tAll = tic;

for idx = 1:nNet
    netName   = subDirs(idx).name;
    netFolder = fullfile(baseDir, netName);

    fprintf('\n=== (%d/%d) Processing network: %s ===\n', idx, nNet, netName);

    % 3.1 Find the .mat file (take the first by default)
    matFiles = dir(fullfile(netFolder, '*.mat'));
    if isempty(matFiles)
        warning('  No .mat file found in folder %s. Skipping.', netFolder);
        continue;
    end

    matPath = fullfile(netFolder, matFiles(1).name);
    fprintf('  Using adjacency-matrix file: %s\n', matFiles(1).name);

    % 3.2 Load adjacency matrix G
    S = load(matPath);
    if ~isfield(S, 'G')
        warning('  Variable G not found in %s. Skipping this network.', matFiles(1).name);
        continue;
    end
    G = S.G;

    % 3.3 Sanity checks
    if ~ismatrix(G) || size(G,1) ~= size(G,2)
        warning('  G is not a square matrix in %s. Skipping.', matFiles(1).name);
        continue;
    end

    % 3.4 Preprocess adjacency (match your convention)
    % Remove self-loops + symmetrize + binarize
    G = double(G);
    G(1:size(G,1)+1:end) = 0;          % remove diagonal
    G = sparse(G);

    % Symmetrize and binarize: treat any positive entry as an undirected edge
    G = (G + G.') > 0;
    G = sparse(double(G));

    N = size(G,1);
    fprintf('  Network loaded. #Nodes = %d\n', N);

    % Record network name & N
    T.network_name(idx) = string(netName);
    T.N(idx) = N;

    %% 4. Run igraph community-detection algorithms
    % In this study, the Leading Eigenvector method is computed using BCT.
    % Here we follow the igraph-based set:
    % Walktrap, Label Propagation, Infomap, Louvain, Leiden (modularity).

    % --- 4.1 Walktrap ---
    Ci_walktrap = [];
    t = tic;
    try
        Ci_walktrap = igraph.cluster(G, 'walktrap', 'nSteps', 4); % default=4
        fprintf('  Walktrap done. Time = %.3f s\n', toc(t));
    catch ME
        warning('  Walktrap failed: %s', ME.message);
    end

    % --- 4.2 Label Propagation ---
    Ci_lp = [];
    t = tic;
    try
        Ci_lp = igraph.cluster(G, 'labelpropagation', 'mode', 'all'); % treat as undirected
        fprintf('  LabelPropagation done. Time = %.3f s\n', toc(t));
    catch ME
        warning('  LabelPropagation failed: %s', ME.message);
    end

    % --- 4.3 Infomap ---
    Ci_infomap = [];
    t = tic;
    try
        Ci_infomap = igraph.cluster(G, 'infomap', 'nTrials', 1); % default=1
        fprintf('  Infomap done. Time = %.3f s\n', toc(t));
    catch ME
        warning('  Infomap failed: %s', ME.message);
    end

    % --- 4.4 Louvain (multilevel) ---
    Ci_louvain = [];
    t = tic;
    try
        Ci_louvain = igraph.cluster(G, 'louvain', 'resolution', 1.0); % aka multilevel
        fprintf('  Louvain done. Time = %.3f s\n', toc(t));
    catch ME
        warning('  Louvain failed: %s', ME.message);
    end

    % --- 4.5 Leiden (modularity) ---The MATLAB implementation of the Leiden algorithm may lead to excessive
    % memory usage for medium-to-large networks**, so Leiden-based results are also recommended 
    % to be computed using the Python version of igraph**, which is also provided in our code section.
    Ci_leidenQ = [];
    t = tic;
    try
        Ci_leidenQ = igraph.cluster(G, 'leiden', ...
            'resolution', 1.0, ...
            'randomness', 0.01, ...
            'metric', 'modularity');
        fprintf('  Leiden(modularity) done. Time = %.3f s\n', toc(t));
    catch ME
        warning('  Leiden(modularity) failed: %s', ME.message);
    end

    %% 5. Count communities and write results
    T.nComm_Walktrap(idx)  = local_count_communities(Ci_walktrap);
    T.nComm_LabelProp(idx) = local_count_communities(Ci_lp);
    T.nComm_Infomap(idx)   = local_count_communities(Ci_infomap);
    T.nComm_Louvain(idx)   = local_count_communities(Ci_louvain);
    T.nComm_LeidenQ(idx)   = local_count_communities(Ci_leidenQ);

    fprintf('  Community counts: Walktrap=%g, LabelProp=%g, Infomap=%g, Louvain=%g, LeidenQ=%g\n', ...
        T.nComm_Walktrap(idx), T.nComm_LabelProp(idx), T.nComm_Infomap(idx), ...
        T.nComm_Louvain(idx), T.nComm_LeidenQ(idx));
end

%% 7. Save the summary table
outMat = fullfile(baseDir, 'community_summary_igraph.mat');
outCsv = fullfile(baseDir, 'community_summary_igraph.csv');

save(outMat, 'T');
writetable(T, outCsv);

fprintf('\nAll processing completed.\n');
fprintf('Total time = %.3f seconds\n', toc(tAll));
fprintf('Results saved to:\n  %s\n  %s\n', outMat, outCsv);
fprintf('Demo completed.\n');

end

%% ===== Local helper function: count the number of communities =====
function n = local_count_communities(Ci)
    if isempty(Ci)
        n = NaN;
        return;
    end
    Ci = Ci(:);
    Ci = Ci(~isnan(Ci));
    if isempty(Ci)
        n = NaN;
    else
        n = numel(unique(Ci));
    end
end
